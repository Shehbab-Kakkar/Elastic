SHELL=/bin/bash
PATH=/sbin:/bin:/usr/sbin:/usr/bin
* * * * * curator ./delete_filebeat.yml  --config ./curator.yml --dry-run  > /root/filebeat.log 2>&1
*/2 * * * * curator ./delete_metricbeat.yml  --config ./curator.yml --dry-run > /root/metricbeat.log 2>&1
